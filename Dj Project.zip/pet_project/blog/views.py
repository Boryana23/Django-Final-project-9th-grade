from django.shortcuts import render
from .models import Post

post=[
    {
        'author':'BB',
        'title':'Blog post one',
        'content': 'First post content',
        'date_posted':'June 08, 2020'
    },
    {
        'author':'John',
        'title':'Blog post two',
        'content': 'Second post content',
        'date_posted':'June 08, 2020'
    }
]

def home(request):
    context={
        'posts': Post.objects.all()
    }
    return render(request, 'blog/home.html', context)

def about(request):
    return render(request, 'blog/about.html', {'title':'About'})
